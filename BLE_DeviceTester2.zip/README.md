# BLE Device Tester 2
by Taehoon Kim

---
## Description
Made for [Comfable](https://comfable.com/) project.

----
## What is used here?
1. [Cordova](https://cordova.apache.org/)
2. [Framework7 - version 1](http://v1.framework7.io/)  
3. Cordova plugins

----
![alt text](https://github.com/hoonblizz/BLE_DeviceTester2/blob/master/img/preview/mainPage.PNG "Preview")
