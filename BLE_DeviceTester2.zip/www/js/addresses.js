/*
	Variables, addresses
*/

// All addresses
let adds = {
	restUUID: '-0000-1000-8000-00805f9b34fb',
	serviceUUID: '00000001',
	serviceUUID2: '0000180f',

	checkFirstTimeSinceBattery_service: '00000001',
	checkFirstTimeSinceBattery_char: '00001122',

	writeSecondsUntilMidnight_service: '00000001',
	writeSecondsUntilMidnight_char: '00003001',

	writeSecondsUntilSuntime_service: '00000001',
	writeSecondsUntilSunrise_char: '00003002',
	writeSecondsUntilSunset_char: '00003003',

	writeTTB_service: '00000001',
	writeTTB_char: '00003000',

	startReadRealtime_service1: '00000001',
	startReadRealtime_service2: '0000180F',
	startReadRealtime_char1: '00001112',
	startReadRealtime_char2: '00001115',
	startReadRealtime_char3: '00001120',
	startReadRealtime_char4: '00001121',
	startReadRealtime_char5: '00001111',
	startReadRealtime_char6: '00001114',
	startReadRealtime_char7: '00002000',
	startReadRealtime_char8: '00002001',
	startReadRealtime_char9: '00001113',
	startReadRealtime_char10: '00001115',
	startReadRealtime_char11: '00001118', // 00002A19
	startReadRealtime_char12: '00001116',
	startReadRealtime_char13: '00001123',
	startReadRealtime_char14: '00001124',
	startReadRealtime_char15: '00002002',
	startReadRealtime_char16: '00002003',
	startReadRealtime_char17: '00002004',

	resetTTB_service: '00000001',
	resetTTB_char: '00001910',

	startNotification_service: '00000001',
	startNotification_char1: '00001910',
	startNotification_char2: '00001920',

	startSendingBytes_service: '00000001',
	startSendingBytes_char: '00004000',

	startUVChange_service: '00000001',
	startUVChange_char: '00004001',

	startOTA_service: '00000001',
	startOTA_char: '00001800',

	notificationTester_service: '00000001',
	notificationTester_char1: '00002005',
	notificationTester_char2: '00002006',
	notificationTester_char3: '00002007',
	notificationTester_char4: '00002008',
	notificationTester_char5: '00002009',
	notificationTester_char7: '00002010',

	customPassword_service: '00000001',
	customPassword_char: '00002100'

}

// All sensitive variables
let dVar = {

	batteryTestingData_fileName: 'qsun2BatteryTester.csv',
	batteryTestingData_emailTo: ['justin@comfable.com', 'mike@comfable.com', 'taehoon@comfable.com'],

	createCSVDataString_fileName: 'qsun2DataLog.csv',
	createCSVDataString_emailTo: ['justin@comfable.com', 'mike@comfable.com', 'taehoon@comfable.com'],
	createCSVDataString_raw_fileName: 'qsun2DataLog_RAW.csv',

	sampleUserPassword: 4321,

	weatherAPIUrlHead: 'https://api.darksky.net/forecast/c6f8f1ec6de2f17011eb59c6a0e4db7a/',
	weatherAPIUrlTail: '?solar'

}